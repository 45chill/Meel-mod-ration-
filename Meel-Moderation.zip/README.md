# Meel Modération 🎮

Bot Discord Python avec commandes slash.

## Installation locale
1. Installer Python 3.11 ou plus récent.
2. Installer les dépendances : `pip install -r requirements.txt`
3. Renommer `.env.example` en `.env`.
4. Ajouter le token Discord dans `.env`.
5. Lancer : `python main.py`

Ne partage jamais ton token Discord.
