import os
import discord
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")

intents = discord.Intents.default()
intents.members = True
intents.message_content = True

class MeelModeration(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix="!",
            intents=intents,
            help_command=None
        )

    async def setup_hook(self):
        await self.load_extension("cogs.moderation")
        await self.load_extension("cogs.fun")
        await self.tree.sync()

    async def on_ready(self):
        print(f"✅ Connecté en tant que {self.user} | {self.user.id}")

bot = MeelModeration()

@bot.tree.command(name="help", description="Affiche l'aide / Shows help")
async def help_command(interaction: discord.Interaction):
    embed = discord.Embed(
        title="🎮 Meel Modération",
        description=(
            "🇫🇷 Utilise `/language` pour choisir ta langue.\n"
            "🇬🇧 Use `/language` to choose your language.\n\n"
            "**Commandes disponibles :**\n"
            "🛡️ `/clear`, `/kick`, `/ban`, `/timeout`\n"
            "🎲 `/coinflip`, `/dice`, `/8ball`"
        )
    )
    await interaction.response.send_message(embed=embed, ephemeral=True)

@bot.tree.command(name="language", description="Choisir la langue / Choose language")
@discord.app_commands.describe(lang="fr ou en")
async def language(interaction: discord.Interaction, lang: str):
    lang = lang.lower()
    if lang not in ("fr", "en"):
        await interaction.response.send_message("Choisis `fr` ou `en`.", ephemeral=True)
        return
    await interaction.response.send_message(
        "🇫🇷 Langue choisie : français." if lang == "fr"
        else "🇬🇧 Language selected: English.",
        ephemeral=True
    )

if not TOKEN or TOKEN == "COLLE_TON_TOKEN_ICI":
    raise RuntimeError("Ajoute ton token dans la variable DISCORD_TOKEN.")

bot.run(TOKEN)
