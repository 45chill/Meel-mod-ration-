import discord
from datetime import timedelta
from discord.ext import commands

class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @discord.app_commands.command(name="clear", description="Supprimer des messages")
    @discord.app_commands.checks.has_permissions(manage_messages=True)
    async def clear(self, interaction: discord.Interaction, amount: int):
        if amount < 1 or amount > 100:
            await interaction.response.send_message("Choisis un nombre entre 1 et 100.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        deleted = await interaction.channel.purge(limit=amount)
        await interaction.followup.send(f"🧹 {len(deleted)} message(s) supprimé(s).", ephemeral=True)

    @discord.app_commands.command(name="kick", description="Expulser un membre")
    @discord.app_commands.checks.has_permissions(kick_members=True)
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: str = "Aucune raison"):
        await member.kick(reason=reason)
        await interaction.response.send_message(f"👢 {member.mention} a été expulsé.")

    @discord.app_commands.command(name="ban", description="Bannir un membre")
    @discord.app_commands.checks.has_permissions(ban_members=True)
    async def ban(self, interaction: discord.Interaction, member: discord.Member, reason: str = "Aucune raison"):
        await member.ban(reason=reason)
        await interaction.response.send_message(f"🔨 {member} a été banni.")

    @discord.app_commands.command(name="timeout", description="Mettre un membre en timeout")
    @discord.app_commands.checks.has_permissions(moderate_members=True)
    async def timeout(self, interaction: discord.Interaction, member: discord.Member, minutes: int):
        if minutes < 1 or minutes > 40320:
            await interaction.response.send_message("Durée invalide.", ephemeral=True)
            return
        until = discord.utils.utcnow() + timedelta(minutes=minutes)
        await member.timeout(until, reason="Timeout via Meel Modération")
        await interaction.response.send_message(f"⏳ {member.mention} est en timeout pour {minutes} minute(s).")

async def setup(bot):
    await bot.add_cog(Moderation(bot))
