import random
import discord
from discord.ext import commands

class Fun(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @discord.app_commands.command(name="coinflip", description="Pile ou face")
    async def coinflip(self, interaction: discord.Interaction):
        await interaction.response.send_message("🪙 " + random.choice(["Pile !", "Face !"]))

    @discord.app_commands.command(name="dice", description="Lancer un dé")
    async def dice(self, interaction: discord.Interaction):
        await interaction.response.send_message(f"🎲 Résultat : **{random.randint(1, 6)}**")

    @discord.app_commands.command(name="8ball", description="Poser une question")
    async def eightball(self, interaction: discord.Interaction, question: str):
        answers = ["Oui !", "Non !", "Peut-être...", "Certainement !", "Je ne sais pas."]
        await interaction.response.send_message(f"🔮 {random.choice(answers)}")

async def setup(bot):
    await bot.add_cog(Fun(bot))
